import { Component } from '@angular/core';

@Component({
  selector: 'app-subject-teacher-list',
  templateUrl: './subject-teacher-list.component.html',
  styleUrls: ['./subject-teacher-list.component.scss']
})
export class SubjectTeacherListComponent {

}
