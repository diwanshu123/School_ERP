import { Component } from '@angular/core';

@Component({
  selector: 'app-class-teacher-list',
  templateUrl: './class-teacher-list.component.html',
  styleUrls: ['./class-teacher-list.component.scss']
})
export class ClassTeacherListComponent {

}
