import { Component } from '@angular/core';

@Component({
  selector: 'app-human-ressource',
  templateUrl: './human-ressource.component.html',
  styleUrls: ['./human-ressource.component.scss']
})
export class HumanRessourceComponent {

}
