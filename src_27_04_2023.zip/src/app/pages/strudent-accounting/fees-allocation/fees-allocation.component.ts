import { Component } from '@angular/core';

@Component({
  selector: 'app-fees-allocation',
  templateUrl: './fees-allocation.component.html',
  styleUrls: ['./fees-allocation.component.scss']
})
export class FeesAllocationComponent {

}
