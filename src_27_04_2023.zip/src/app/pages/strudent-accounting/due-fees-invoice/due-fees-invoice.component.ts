import { Component } from '@angular/core';

@Component({
  selector: 'app-due-fees-invoice',
  templateUrl: './due-fees-invoice.component.html',
  styleUrls: ['./due-fees-invoice.component.scss']
})
export class DueFeesInvoiceComponent {

}
