import { Component } from '@angular/core';

@Component({
  selector: 'app-multiple-import',
  templateUrl: './multiple-import.component.html',
  styleUrls: ['./multiple-import.component.scss']
})
export class MultipleImportComponent {

}
