import { Component } from '@angular/core';

@Component({
  selector: 'app-advanced-salary',
  templateUrl: './advanced-salary.component.html',
  styleUrls: ['./advanced-salary.component.scss']
})
export class AdvancedSalaryComponent {

}
