import { Component } from '@angular/core';

@Component({
  selector: 'app-stud-info-books',
  templateUrl: './stud-info-books.component.html',
  styleUrls: ['./stud-info-books.component.scss']
})
export class StudInfoBooksComponent {

}
