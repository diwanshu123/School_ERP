import { Component } from '@angular/core';

@Component({
  selector: 'app-strudent-accounting',
  templateUrl: './strudent-accounting.component.html',
  styleUrls: ['./strudent-accounting.component.scss']
})
export class StrudentAccountingComponent {

}
