import { Component } from '@angular/core';

@Component({
  selector: 'app-fees-remainder',
  templateUrl: './fees-remainder.component.html',
  styleUrls: ['./fees-remainder.component.scss']
})
export class FeesRemainderComponent {

}
