import { Component } from '@angular/core';

@Component({
  selector: 'app-invoice-collect-paid',
  templateUrl: './invoice-collect-paid.component.html',
  styleUrls: ['./invoice-collect-paid.component.scss']
})
export class InvoiceCollectPaidComponent {

}
