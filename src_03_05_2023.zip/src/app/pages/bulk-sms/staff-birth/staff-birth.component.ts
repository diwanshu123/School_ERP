import { Component } from '@angular/core';

@Component({
  selector: 'app-staff-birth',
  templateUrl: './staff-birth.component.html',
  styleUrls: ['./staff-birth.component.scss']
})
export class StaffBirthComponent {

}
