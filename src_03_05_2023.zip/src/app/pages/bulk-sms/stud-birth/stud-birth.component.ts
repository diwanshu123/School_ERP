import { Component } from '@angular/core';

@Component({
  selector: 'app-stud-birth',
  templateUrl: './stud-birth.component.html',
  styleUrls: ['./stud-birth.component.scss']
})
export class StudBirthComponent {

}
