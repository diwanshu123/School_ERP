import { Component } from '@angular/core';

@Component({
  selector: 'app-fees-consession-report',
  templateUrl: './fees-consession-report.component.html',
  styleUrls: ['./fees-consession-report.component.scss']
})
export class FeesConsessionReportComponent {

}
