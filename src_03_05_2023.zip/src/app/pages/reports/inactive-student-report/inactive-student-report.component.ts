import { Component } from '@angular/core';

@Component({
  selector: 'app-inactive-student-report',
  templateUrl: './inactive-student-report.component.html',
  styleUrls: ['./inactive-student-report.component.scss']
})
export class InactiveStudentReportComponent {

}
