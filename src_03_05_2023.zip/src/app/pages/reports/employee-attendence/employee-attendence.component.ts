import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-attendence',
  templateUrl: './employee-attendence.component.html',
  styleUrls: ['./employee-attendence.component.scss']
})
export class EmployeeAttendenceComponent {

}
