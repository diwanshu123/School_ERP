import { Component } from '@angular/core';

@Component({
  selector: 'app-student-strength-report',
  templateUrl: './student-strength-report.component.html',
  styleUrls: ['./student-strength-report.component.scss']
})
export class StudentStrengthReportComponent {

}
