import { Component } from '@angular/core';

@Component({
  selector: 'app-admission-details-reports',
  templateUrl: './admission-details-reports.component.html',
  styleUrls: ['./admission-details-reports.component.scss']
})
export class AdmissionDetailsReportsComponent {

}
